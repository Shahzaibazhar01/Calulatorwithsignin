package com.example.assnment01;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {
    EditText fullNameInput, emailInput, mobileInput, passwordInput, confirmPasswordInput;
    Button signUpButton;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        fullNameInput = findViewById(R.id.edtSignUpFullName);
        emailInput = findViewById(R.id.edtSignUpEmail);
        mobileInput = findViewById(R.id.edtSignUpMobile);
        passwordInput = findViewById(R.id.edtSignUpPassword);
        confirmPasswordInput = findViewById(R.id.edtSignUpConfirmPassword);
        signUpButton = findViewById(R.id.btnSignUp);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = fullNameInput.getText().toString().trim();
                String email = emailInput.getText().toString().trim();
                String mobile = mobileInput.getText().toString().trim();
                String password = passwordInput.getText().toString();
                String confirmPassword = confirmPasswordInput.getText().toString();

                if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(mobile) ||
                        TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(SignUpActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(SignUpActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save sign-up information in SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("fullName", fullName);
                editor.putString("email", email);
                editor.putString("mobile", mobile);
                editor.putString("password", password);
                editor.apply();

                Toast.makeText(SignUpActivity.this, "Sign up successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                finish(); // Finish the activity and go back to the previous screen
            }
        });
    }
}
